#ifndef __HELLOWORLD_SCENE_H__
#define __HELLOWORLD_SCENE_H__

#include "cocos2d.h"

const static int CELL_ROW   = 11;   // 行数
const static int CELL_COL   = 11;   // 列数
const static int CELL_SPACE = 3;    // 间隙

const static int CELL_W = 50;   // 每个CELL的宽
const static int CELL_H = 50;   // 每个CELL的高

USING_NS_CC;

class HelloWorld : public cocos2d::Layer
{
public:
    static cocos2d::Scene* createScene();
    virtual bool init() override;
    CREATE_FUNC(HelloWorld);
    
private:
    // 老鼠结构体
    typedef struct _Mouse{
        bool    _bLive; // 生命体状态
        Vec2    _vPos;  // 在数组中的位置, 使用时候需要强转int
        Sprite* _pSkin; // 皮肤黑表示生存,白表示死亡
        
        // 设老鼠的生命状态 并修改其图片
        void setLifeStats(bool live){
            _bLive = live;
            const std::string file = (_bLive ? "black.png" : "white.png");
            _pSkin->setTexture(file);
        }
    } Mouse;
    
private:
    // 用数组创建 CELL_ROW * CELL_COL个方格,表示老鼠
    Mouse   _pMouse[CELL_ROW][CELL_COL];
    // 为了在一轮完成后才去修改老鼠的状态, 达到同时被规则
    bool    _bLifeBuffer[CELL_ROW][CELL_COL] = {0};
    
private:
    /**
     * @brief 初始化小白鼠的状态.种子也在这里面
     */
    void initExamTest();
    
    /**
     * @brief 设置种子
     */
    void setSrandData();
    
    /**
     * @brief 每隔几秒去检测一次
     */
    void updateCheck(float dt);
    
    /**
     * @brief 检测某个小白鼠的状态
     */
    void checkAlive(Mouse m);
    
    /*
     * 位置是否越界
     */
    bool isInRange(const Vec2 &pos);
    
};

#endif // __HELLOWORLD_SCENE_H__
