#include "HelloWorldScene.h"

USING_NS_CC;

Scene* HelloWorld::createScene()
{
    auto scene = Scene::create();
    auto layer = HelloWorld::create();
    scene->addChild(layer);
    return scene;
}

bool HelloWorld::init()
{
    if ( !Layer::init() )
    {
        return false;
    }
    
    // background 避免黑色背景和 黑色方块重复
    LayerColor *layer = LayerColor::create(Color4B(106, 50, 5, 255));
    layer->setPosition(Vec2::ZERO);
    layer->setAnchorPoint(Vec2::ZERO);
    this->addChild(layer);
    
    // 初始化小白鼠
    this->initExamTest();
    // 设置种子
    this->setSrandData();
    // 每隔1s去看小白鼠的状态
    this->schedule(schedule_selector(HelloWorld::updateCheck), 1.0f, kRepeatForever, 1.0f);
    
    return true;
}


void HelloWorld::initExamTest()
{
    
    //
    float startX = 50;
    float startY = 200;
    for (int i = 0; i < CELL_ROW; i++) {
        for (int j = 0; j < CELL_COL; j++) {
            Sprite *cell = Sprite::create("white.png");
            cell->setPosition(startX, startY);
            this->addChild(cell);
            HelloWorld::Mouse mouse = HelloWorld::Mouse{false, Vec2(i, j), cell};
            _pMouse[i][j] = mouse;
            startX += (CELL_W + CELL_SPACE);
        }
        startX = 50;
        startY += (CELL_H + CELL_SPACE);
    }
    
}

void HelloWorld::setSrandData()
{
    // 初始化小白鼠的状态 for test 左下角(0, 0), true表示生存,反之易知. 也是题干中的"种子"
    const bool testLive[CELL_ROW][CELL_COL] = {
        false,  true,   false,  false,  false,  false,  false,  false,  false,  true,   false,
        true,   true,   false,  false,  false,  false,  true,   false,  true,   false,  false,
        false,  true,   false,  true,   false,  true,   false,  false,  true,   true,   false,
        false,  true,   false,  true,   true,   false,  false,  false,  false,  false,  true,
        true,   false,  false,  false,  true,   false,  false,  false,  true,   false,  false,
        false,  false,  false,  false,  false,  true,   false,  true,   false,  false,  false,
        false,  false,  false,  false,  false,  false,  false,  false,  false,  false,  false,
        false,  false,  false,  false,  false,  false,  false,  false,  false,  false,  false,
        true,   false,  false,  false,  false,  false,  false,  false,  false,  false,  false,
        true,   true,   false,  false,  false,  false,  false,  false,  false,  false,  false,
        true,   true,   false,  true,   false,  false,  false,  false,  false,  false,  false
    };
    for (int i = 0; i < CELL_ROW; i++) {
        for (int j = 0; j < CELL_COL; j++) {
            _pMouse[i][j].setLifeStats(testLive[CELL_ROW - i - 1][j]);
        }
    }
}

void HelloWorld::updateCheck(float dt)
{
    // 先检测,有哪些是需要改变的.并把改变的状态存到_bLifeBuffer数组中
    for (int i = 0; i < CELL_ROW; i++) {
        for (int j = 0; j < CELL_COL; j++) {
            // TODO:在下面方法里面每个最多需要遍历8次,一共(8 * CELL_ROW * CELL_COL)次.
            this->checkAlive(_pMouse[i][j]);
        }
    }
    
    // 达到同时被规则了,才改变. 此处 是当每次遍历完了才改变状态.
    for (int i = 0; i < CELL_ROW; i++) {
        for (int j = 0; j < CELL_COL; j++) {
            _pMouse[i][j].setLifeStats(_bLifeBuffer[i][j]);
        }
    }
}

void HelloWorld::checkAlive(Mouse m)
{
    std::vector<Vec2> vRounds = {
        m._vPos + Vec2(-1, -1), // left bottom
        m._vPos + Vec2(-1, 0),  // bottom
        m._vPos + Vec2(-1, 1),  // right bottom
        m._vPos + Vec2(0, -1),  // left
        m._vPos + Vec2(0, 1),   // right
        m._vPos + Vec2(1, -1),  // top left
        m._vPos + Vec2(1, 0),   // top
        m._vPos + Vec2(1, 1)    // top right
    };
    int live = 0;
    for (auto it : vRounds) {
        if (isInRange(it) && _pMouse[(int)it.x][(int)it.y]._bLive) {
            live++;
        }
    }
    _bLifeBuffer[(int)m._vPos.x][(int)m._vPos.y] = m._bLive;
    if (m._bLive) {
        if(live < 2 || live > 3) {// 成死亡 状态
            _bLifeBuffer[(int)m._vPos.x][(int)m._vPos.y] = false;
        }
    } else {
        _bLifeBuffer[(int)m._vPos.x][(int)m._vPos.y] = (live == 3);
    }
}

bool HelloWorld::isInRange(const cocos2d::Vec2 &pos)
{
    if (pos.x < 0 || pos.x >= CELL_COL || pos.y < 0 || pos.y >= CELL_ROW) {
        return false;
    }
    return true;
}
